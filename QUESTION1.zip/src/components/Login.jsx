import React, { useState } from "react";

const Login = () => {
  const [name, setName] = useState();
  const [password, setPassword] = useState();
  const [token, setToken] = useState(null);

  const submitHandler = (e) => {
    const sendReq = async () => {
      const response = await fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: name,
          password: password,
        }),
      });
      const data = await response.json();

      setToken(data.token);
      localStorage.setItem("token", data.token);
      console.log(data);
    };
    sendReq();
    e.preventDefault();
  };
  return (
    <div>
      <h1 className="main">Login</h1>

      <form
        className="credentials"
        action=""
        method="post"
        onSubmit={submitHandler}
      >
        <input
          className="box"
          type="text"
          placeholder="Username"
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="password"
          className="box"
          placeholder="password"
          onChange={(e) => setPassword(e.target.value)}
        />
        <button className="button" type="submit">
          Login
        </button>
      </form>
      {token && <div>Token is {token}</div>}
    </div>
  );
};
export default Login;
